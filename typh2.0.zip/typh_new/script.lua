require('GSAnimBlend')
local squapi = require('SquAPI')

-- Smooth head (+ neck) rotation --
local head = squapi.smoothHead:new(
        {
            models.model.MRoot.Root.MAllBody.AllBody.MUpBody.UpBody.MUpperBody.UpperBody.AllHead.Neck,
            models.model.MRoot.Root.MAllBody.AllBody.MUpBody.UpBody.MUpperBody.UpperBody.AllHead.Head,
        },
        0.1
)

-- Eye setup --
squapi.eye:new(
    models.model.MRoot.Root.MAllBody.AllBody.MUpBody.UpBody.MUpperBody.UpperBody.AllHead.Neck.Head.Eyes.Eyelid.RightEyelid.RightEyelidBase,
    0.5,
    0.2,
    0.7,
    0.1
)
squapi.eye:new(
    models.model.MRoot.Root.MAllBody.AllBody.MUpBody.UpBody.MUpperBody.UpperBody.AllHead.Neck.Head.Eyes.Eyelid.LeftEyelid.LeftEyelidBase,
    0.2,
    0.4,
    0.7,
    0.1
)

-- Eye blink --
squapi.randimation:new(
    animations.model.blink,
    50,
    250,
    true
)


nameplate.ALL:setText(
   toJson({
       { text = 'Typh', color = '#ffffff' }
   })
)

vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(false)

-- Emote wheel --
local outfitPage = action_wheel:newPage()
action_wheel:setPage(outfitPage)

-- Make outfits swaps --
local hoodieModel = models.model.MRoot.Root.MAllBody.AllBody.MUpBody.UpBody.MUpperBody.UpperBody.AllHead.Neck.Head.Hoodie
hoodieModel:setVisible(false)

outfitPage:newAction()
    :title("Outfit 1")
    :item("leather_chestplate")
    :onLeftClick(function()
        models:setPrimaryTexture("Custom", textures["outfit_1"])
        hoodieModel:setVisible(false)
end)

outfitPage:newAction()
    :title("Outfit 2")
    :item("iron_chestplate")
    :onLeftClick(function()
        models:setPrimaryTexture("Custom", textures["outfit_2"])
        hoodieModel:setVisible(false)
end)

outfitPage:newAction()
    :title("Outfit 3")
    :item("diamond_chestplate")
    :onLeftClick(function()
        models:setPrimaryTexture("Custom", textures["outfit_3"])
        hoodieModel:setPrimaryTexture("Custom", textures["hoodie"])
        hoodieModel:setVisible(true)
end)

local holdingShieldState = true
function pings.examplePing(state)
    holdingShieldState = state
end
local rclick = keybinds:newKeybind("Right click", "key.mouse.right")
rclick.press = function()
    pings.examplePing(false)
end
rclick.release = function()
    pings.examplePing(true)
end

function events.tick()
    local pose = player:getPose()
    local velocity = player:getVelocity()
    local moving = velocity.xz:length() > 0.01
    local vehicle = player:getVehicle()

    if (#animations:getPlaying(true) > 0) then
        if not (animations.model.idle:isPlaying()) then
            head.strength[1] = 1
        else
            head.strength[1] = 0.1
        end
    else
        head.strength[1] = 0.1
    end

    local blocking = player:isBlocking()
    local fishing = player:isFishing()
    -- Different riding animations for different vehicles
    local boating = vehicle and vehicle:getType():find("boat")
    local horseriding = vehicle and vehicle:getType():find("horse")
    local carting = vehicle and vehicle:getType():find("minecart")
    local pigriding = vehicle and vehicle:getType():find("pig")
    local striderriding = vehicle and vehicle:getType():find("strider")

    animations.model.ridepig:setPlaying(pigriding or striderriding)
    animations.model.sit:setPlaying(horseriding)
    animations.model.boat:setPlaying(boating or carting)
    animations.model.holdshieldR:setPlaying(player:getHeldItem(false).id=="minecraft:shield" and holdingShieldState)
    animations.model.holdshieldL:setPlaying(player:getHeldItem(true).id=="minecraft:shield" and holdingShieldState)
end
