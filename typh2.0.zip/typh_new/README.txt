Thank you for purchasing this model! :D

---

Credits:
- Model and texture by me!
- Scripts used:
  - EZAnims (lightly modified to support extra animations): https://github.com/JimmyHelp/JimmyAnims
  - GSAnimBlend: https://github.com/GrandpaScout/GSAnimBlend
  - SquAPI (Used for smooth head rotation, eye movement and blinks): https://github.com/MrSirSquishy/SquishyAPI